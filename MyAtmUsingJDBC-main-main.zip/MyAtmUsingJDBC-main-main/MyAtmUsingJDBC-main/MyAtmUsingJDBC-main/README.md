# MyAtmUsingJDBC
Using JDBC, I created MyAtm. This ATM offers a limited number of services to the user and is also connected to a database; all transaction validation, credential storage, and account balance storage occurs in the database exclusively.
